file="F_1KB.txt"
for num in $(seq 1 3)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_2KB.txt"
for num in $(seq 1 6)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_3KB.txt"
for num in $(seq 1 9)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_4KB.txt"
for num in $(seq 1 12)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_5KB.txt"
for num in $(seq 1 15)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_6KB.txt"
for num in $(seq 1 18)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_7KB.txt"
for num in $(seq 1 21)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_8kb.txt"
for num in $(seq 1 24)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_9KB.txt"
for num in $(seq 1 27)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_10KB.txt"
for num in $(seq 1 30)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F_100kb.txt"
for num in $(seq 1 300)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done
