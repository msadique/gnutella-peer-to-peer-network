//enum QueryType having some values related to the type of Query client initiates.

public enum QueryType {
	Request,
	Response,
	Download
	}
	

